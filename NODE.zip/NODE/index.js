import axios from "axios"
import fs from "fs-extra"
import path from "path"
import prettier from "prettier"

//gsk_XanbB10UU
//zOudEeqV9CUWGdyb3FY
//sNf1bXz0dMYow6W1dHg0N6WP

//gsk_YFh3f7cicHHAchqpMj
//MaWGdyb3FYK7Jnp
//kgGHLY7zpYqo0rJeotB


//gsk_lKxiDtjPvIQRlyXf6
//07CWGdyb3FYQt2R
//9ThqjkaAcswEeTxTPeMP

const GROQ_API_KEY = ""


const args = process.argv.slice(2)

let dir = "output"
let promptParts = []

for (let i = 0; i < args.length; i++) {
  if (args[i] === "--dir") {
    dir = args[i + 1]
    i++
  } else {
    promptParts.push(args[i])
  }
}

const prompt = promptParts.join(" ")

if (!prompt) {
  console.log("Usage: node index.js \"<your prompt>\" --dir <output-folder>")
  process.exit(1)
}

const SYSTEM_PROMPT = `You are an expert senior software engineer and code generator.

Your job: read the user's prompt carefully and generate a complete, fully working project using EXACTLY the technology they ask for.

- If they say React → generate a Vite + React project using .jsx files. Structure: index.html at root, src/main.jsx as entry, src/App.jsx as root component, src/components/ for components, package.json with vite + react dependencies, vite.config.js. Do NOT use Create React App.
- If they say React + TypeScript → Vite + React with .tsx files + tsconfig.json
- If they say TypeScript (without React) → use .ts files with proper types, interfaces, and a tsconfig.json
- If they say JavaScript → use .js files with plain JS only
- If they say HTML/CSS → generate .html and .css files
- If they say Vue, Angular, Express, Next.js, etc. → use that framework with its standard project structure
- Follow the user's stack exactly. Do not substitute or change the language/framework.

Respond ONLY with a valid JSON object in this exact format:
{
  "files": [
    {
      "path": "relative/path/to/file.ext",
      "content": "full file content here"
    }
  ]
}

STRICT RULES:
1. All files must be 100% complete and fully functional. No placeholders, no TODOs.
2. Code MUST be properly indented (2 spaces) with real newlines. Never minify or write everything on one line.
3. ZERO comments. No comment lines, no inline comments, no block comments anywhere in the code.
4. NEVER mix languages - no TypeScript syntax in .js files, no JSX in .ts files, etc.
5. Include every file the project needs to run (package.json, tsconfig.json, index.html, etc.).
6. Do NOT output anything outside the JSON object - no explanation, no markdown.`

const PARSER_MAP = {
  ".js": "babel",
  ".jsx": "babel",
  ".ts": "typescript",
  ".tsx": "typescript",
  ".html": "html",
  ".css": "css",
  ".json": "json",
  ".md": "markdown",
}

const formatContent = async (content, filePath) => {
  const ext = path.extname(filePath).toLowerCase()
  const parser = PARSER_MAP[ext]
  if (!parser) return content
  try {
    return await prettier.format(content, {
      parser,
      printWidth: 80,
      tabWidth: 2,
      semi: true,
      singleQuote: true,
      trailingComma: "es5",
    })
  } catch {
    return content
  }
}

const generate = async () => {
  console.log(`\nGenerating: "${prompt}"`)
  console.log(`Output dir: ./${dir}\n`)

  try {
    const res = await axios.post(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        model: "llama-3.3-70b-versatile",
        response_format: { type: "json_object" },
        temperature: 0.2,
        max_tokens: 8000,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: prompt }
        ]
      },
      {
        headers: {
          Authorization: `Bearer ${GROQ_API_KEY}`,
          "Content-Type": "application/json"
        },
        timeout: 120000
      }
    )

    const rawContent = res.data.choices[0].message.content.trim()

    let parsed
    try {
      parsed = JSON.parse(rawContent)
    } catch {
      console.error("Failed to parse JSON from model.")
      console.error("Raw output:\n", rawContent.slice(0, 500))
      process.exit(1)
    }

    if (!parsed.files || !Array.isArray(parsed.files) || parsed.files.length === 0) {
      console.error("Response missing 'files' array.")
      process.exit(1)
    }

    for (const file of parsed.files) {
      const filePath = path.join(process.cwd(), dir, file.path)
      await fs.ensureDir(path.dirname(filePath))
      const formatted = await formatContent(file.content, file.path)
      await fs.writeFile(filePath, formatted)
      console.log(`  Created: ${file.path}`)
    }

    console.log(`\nDone! Project generated in ./${dir}`)
  } catch (e) {
    if (e.response) {
      console.error("API Error:", JSON.stringify(e.response.data, null, 2))
    } else {
      console.error("Error:", e.message)
    }
    process.exit(1)
  }
}

generate()